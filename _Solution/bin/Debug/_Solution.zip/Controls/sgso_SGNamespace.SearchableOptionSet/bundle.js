var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./SearchableOptionSet/index.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./SearchableOptionSet/index.ts":
/*!**************************************!*\
  !*** ./SearchableOptionSet/index.ts ***!
  \**************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nexports.SearchableOptionSet = void 0;\n\nvar SearchableOptionSet =\n/** @class */\nfunction () {\n  /**\r\n   * Empty constructor.\r\n   */\n  function SearchableOptionSet() {}\n  /**\r\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\r\n   * Data-set values are not initialized here, use updateView.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\r\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\r\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\r\n   * @param container If a control is marked control-type='standard', it will receive an empty div element within which it can render its content.\r\n   */\n\n\n  SearchableOptionSet.prototype.init = function (context, notifyOutputChanged, state, container) {\n    var _a, _b, _c;\n\n    this._notifyOutputChanged = notifyOutputChanged;\n    this.sourceOptionSet = context.parameters.InputOptionSet;\n    this.entityId = context.mode.contextInfo.entityId;\n    this.defaultOption = this.sourceOptionSet.raw || null;\n    this.defaultValue = (_a = this.sourceOptionSet.attributes) === null || _a === void 0 ? void 0 : _a.DefaultValue;\n    var sourceOptions = new Array();\n    (_b = this.sourceOptionSet.attributes) === null || _b === void 0 ? void 0 : _b.Options.forEach(function (e) {\n      sourceOptions.push(e);\n    });\n    var isSorted = ((_c = context.parameters.AlphabeticalOrder) === null || _c === void 0 ? void 0 : _c.raw) || \"1\";\n\n    if (isSorted == \"1\") {\n      sourceOptions.sort(function (a, b) {\n        return a.Label.localeCompare(b.Label);\n      });\n      ;\n    }\n\n    this.sourceOptions = sourceOptions;\n    var datalistGUID = this.GenerateDatalistGUID();\n    this.targetOptionSet = document.createElement('datalist');\n    this.targetOptionSet.setAttribute(\"id\", datalistGUID);\n    this.targetOptionSet.setAttribute(\"class\", \"TargetOptionSet\");\n    this.targetOptionSet_Input = document.createElement('input');\n    this.targetOptionSet_Input.type = \"text\";\n    this.targetOptionSet_Input.setAttribute(\"list\", datalistGUID);\n    this.targetOptionSet_Input.setAttribute(\"id\", \"searchBox\");\n    this.targetOptionSet_Input.autocomplete = \"off\";\n    this.targetOptionSet_Input.placeholder = context.parameters.SearchBoxPlaceholder.raw || \"---\";\n    this.buildingString = \"\";\n    this.TreatTargetOptionSet(this.targetOptionSet, this.sourceOptions, this.defaultOption, this.defaultValue, this.buildingString, this.entityId);\n    this.flexContainer = document.createElement(\"div\");\n    this.flexContainer.setAttribute(\"class\", \"flexContainer\");\n    this.imgElement = document.createElement(\"img\");\n    context.resources.getResource(\"MagnifyingGlass.png\", this.setImage.bind(this, false, \"png\"), this.showError.bind(this));\n    this.imgContainer = document.createElement(\"div\");\n    this.imgContainer.setAttribute(\"class\", \"imgContainer\");\n    this.datalistContainer = document.createElement(\"div\");\n    this.datalistContainer.setAttribute(\"class\", \"datalistContainer\");\n    this.targetOptionSet_Input.addEventListener(\"change\", this.onOptionChange.bind(this));\n    this.targetOptionSet_Input.addEventListener(\"blur\", this.onBlur.bind(this));\n    container.appendChild(this.flexContainer);\n    this.flexContainer.appendChild(this.imgContainer);\n    this.imgContainer.appendChild(this.imgElement);\n    this.flexContainer.appendChild(this.datalistContainer);\n    this.datalistContainer.appendChild(this.targetOptionSet_Input);\n    this.datalistContainer.appendChild(this.targetOptionSet);\n  };\n  /**\r\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\r\n   */\n\n\n  SearchableOptionSet.prototype.updateView = function (context) {\n    var _a, _b;\n\n    if (context.mode.isControlDisabled) {\n      this.isReadOnly = true;\n      this.DisableTargetOptionSet();\n    }\n\n    this.targetOptionSet.hidden = !context.mode.isVisible;\n    this.securityReadable = (_a = context.parameters.InputOptionSet.security) === null || _a === void 0 ? void 0 : _a.readable;\n    this.securityEditable = (_b = context.parameters.InputOptionSet.security) === null || _b === void 0 ? void 0 : _b.editable;\n\n    if (!this.securityReadable) {\n      this.targetOptionSet_Input.style.visibility = \"hidden\";\n    }\n\n    if (!this.securityEditable) {\n      this.isReadOnly = true;\n      this.DisableTargetOptionSet();\n    }\n  };\n  /**\r\n   * It is called by the framework prior to a control receiving new data.\r\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”\r\n   */\n\n\n  SearchableOptionSet.prototype.getOutputs = function () {\n    return {\n      InputOptionSet: this.tempTargetOptionNb\n    };\n  };\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n\n\n  SearchableOptionSet.prototype.destroy = function () {};\n  /**\r\n  * METHODS\r\n  */\n\n\n  SearchableOptionSet.prototype.GenerateDatalistGUID = function () {\n    var dt = new Date().getTime();\n    var uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {\n      var r = (dt + Math.random() * 16) % 16 | 0;\n      dt = Math.floor(dt / 16);\n      return (c == 'x' ? r : r & 0x3 | 0x8).toString(16);\n    });\n    return uuid;\n  };\n\n  SearchableOptionSet.prototype.TreatTargetOptionSet = function (TargetOptionSet, sourceOptionArray, defaultOption, defaultValue, optionString, EntityId) {\n    optionString += '<option id =\"-1\" value=\"--Select--\" />';\n\n    for (var j = 0; j < sourceOptionArray.length; j++) {\n      optionString += '<option id =\"' + sourceOptionArray[j].Value + '\"value=\"' + sourceOptionArray[j].Label + '\" />';\n      var isSelected = false;\n\n      if (defaultOption == sourceOptionArray[j].Value) {\n        this.targetOptionSet_Input.value = sourceOptionArray[j].Label;\n        isSelected = true;\n      }\n\n      if (defaultValue == sourceOptionArray[j].Value && !isSelected && EntityId == undefined) {\n        this.targetOptionSet_Input.value = sourceOptionArray[j].Label;\n      }\n    }\n\n    TargetOptionSet.innerHTML = optionString;\n  };\n\n  SearchableOptionSet.prototype.DisableTargetOptionSet = function () {\n    for (var i = 0; this.targetOptionSet.options.length; i++) {\n      this.targetOptionSet.options[i].disabled = true;\n    }\n\n    this.targetOptionSet_Input.disabled = true;\n    this.targetOptionSet_Input.readOnly = true;\n  };\n\n  SearchableOptionSet.prototype.onOptionChange = function () {\n    var _a;\n\n    this.targetOptionSet.style.fontWeight = \"normal\";\n\n    if (this.isReadOnly) {\n      return;\n    }\n\n    if (this.IsInputInDatalist(this.targetOptionSet_Input.value)) {\n      this.tempTargetOptionNb = Number((_a = document.querySelector('option[value=\"' + this.targetOptionSet_Input.value + '\"]')) === null || _a === void 0 ? void 0 : _a.id);\n\n      this._notifyOutputChanged();\n    }\n  };\n\n  SearchableOptionSet.prototype.IsInputInDatalist = function (Input) {\n    for (var i = 0; this.targetOptionSet.options.length; i++) {\n      if (Input == this.targetOptionSet.options[i].value) {\n        return true;\n      }\n    }\n\n    return false;\n  };\n\n  SearchableOptionSet.prototype.onBlur = function () {\n    if (this.targetOptionSet_Input.value == \"--Select--\") {\n      this.targetOptionSet_Input.value = \"\";\n    }\n  };\n\n  SearchableOptionSet.prototype.showError = function () {\n    console.log(\"The component img could not be found\");\n  };\n\n  SearchableOptionSet.prototype.setImage = function (shouldUpdateOutput, fileType, fileContent) {\n    var imageUrl = this.generateImageSrcUrl(fileType, fileContent);\n    this.imgElement.src = imageUrl;\n  };\n\n  SearchableOptionSet.prototype.generateImageSrcUrl = function (fileType, fileContent) {\n    return \"data:image/\" + fileType + \";base64, \" + fileContent;\n  };\n\n  return SearchableOptionSet;\n}();\n\nexports.SearchableOptionSet = SearchableOptionSet;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./SearchableOptionSet/index.ts?");

/***/ })

/******/ });
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('SGNamespace.SearchableOptionSet', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.SearchableOptionSet);
} else {
	var SGNamespace = SGNamespace || {};
	SGNamespace.SearchableOptionSet = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.SearchableOptionSet;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}